#1.a
# ratioHumidity = humdity / 100

#1.b
# humidity.shape

#1.c
# Length of the shape is 3 since humidity is a 3D array and shape of it return (x,y,z) tuple that has
# 3 elements in it

# 1.d
# import numpy as np
#
# minValue = np.amin(humdity) # Get the minimum value in the humidity
# newValues = humidity
# newValues[newValues < 50] = minValue
